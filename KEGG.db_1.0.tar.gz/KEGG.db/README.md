# KEGG.db
KEGG.db for GSEAKEGG(human)

用 YuLab-SMU/createKEGGdb 做的

正常来说不用搞离线的，还得更新，但是云平台调用docker连不了KEGG只能这么做了。
